import 'package:flutter/material.dart';

import 'dart:async';

import 'package:pertemuan7_crud/halaman4.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: SplashScreen(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

Widget boxed3() {
  return Container(
    alignment: Alignment.bottomRight,
    child: Container(
      width: 400,
      height: 70,
      decoration: BoxDecoration(
        color: Colors.transparent,
      ),
      child: Stack(children: [
        Container(
          alignment: Alignment.center,
          child: Text('REXTOR SPEED',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 20,
                color: Color.fromARGB(255, 255, 255, 255),
              )),
        ),
        // Container(
        //   alignment: Alignment.centerRight,
        //   margin: EdgeInsets.only(right: 10),
        //   child: Icon(
        //     Icons.more_vert,
        //     color: Colors.white,
        //     size: 30,
        //   ),
        // ),
        // Container(
        //   alignment: Alignment.centerLeft,
        //   margin: EdgeInsets.only(left: 10),
        //   child: Icon(
        //     Icons.menu,
        //     color: Colors.white,
        //     size: 30,
        //   ),
        // )
      ]),
    ),
  );
}

Widget boxed4() {
  return Container(
    alignment: Alignment.center,
    child: Container(
      margin: EdgeInsets.only(
        top: 20,
      ),
      width: 400,
      height: 370,
      decoration: BoxDecoration(
        color: Colors.transparent,
      ),
      child: Stack(children: [
        Container(
          alignment: Alignment.topCenter,
          child: Text('Into Your Home',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 30,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 255, 255, 255),
              )),
        ),
        Container(
          alignment: Alignment.topCenter,
          margin: EdgeInsets.only(top: 50),
          child: Text('With Our Speed',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 20,
                color: Color.fromARGB(255, 255, 255, 255),
              )),
        ),
      ]),
    ),
  );
}

Widget boxed5(BuildContext context) {
  return Container(
    alignment: Alignment.center,
    child: Container(
      margin: EdgeInsets.only(
        top: 60,
      ),
      width: 400,
      height: 370,
      decoration: BoxDecoration(
        color: Colors.transparent,
      ),
      child: Stack(children: [
        Container(
          alignment: Alignment.topCenter,
          child: ElevatedButton(
            onPressed: () {
              final snackBar = SnackBar(
                content: Container(
                  child: Text("Anda Telah Masuk Ke Halaman Awal"),
                ),
                duration: Duration(seconds: 4),
                padding: EdgeInsets.all(10),
                backgroundColor: Colors.red,
              );
              ScaffoldMessenger.of(context).showSnackBar(snackBar);
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return Second();
              }));
            },
            child: Text(
              "Shop Now",
            ),
            style: ElevatedButton.styleFrom(
              primary: Colors.amber,
            ),
          ),
        ),
        Container(
          alignment: Alignment.topCenter,
          margin: EdgeInsets.only(top: 50),
          child: Text('Press To Continue',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 255, 255, 255),
              )),
        ),
      ]),
    ),
  );
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    var tinggi = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
        alignment: Alignment.topLeft,
        width: lebar,
        height: tinggi,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('poto/bg.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: ListView(children: <Widget>[
          boxed3(),
          boxed4(),
          boxed5(context),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [],
            ),
          ),
        ]),
      ),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    splashScreenStart();
  }

  splashScreenStart() {
    var duration = const Duration(seconds: 3);
    return Timer(duration, () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => MyHomePage(),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Image.asset(
          "poto/Piaggio.png",
          width: MediaQuery.of(context).size.width / 2,
          height: MediaQuery.of(context).size.height / 2,
        ),
      ),
    );
  }
}
