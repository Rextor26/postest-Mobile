import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:pertemuan7_crud/halaman4.dart';
import 'package:pertemuan7_crud/item_card.dart';

class AddData extends StatelessWidget {
  final nama = new TextEditingController();
  final ttl = new TextEditingController();
  final alamat = new TextEditingController();
  final email = new TextEditingController();
  final noHp = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    FirebaseFirestore firestore = FirebaseFirestore.instance;
    CollectionReference users = firestore.collection('posttest7');
    return Scaffold(
        // appBar: AppBar(
        //   title: Text(
        //     'Profile',
        //     style: TextStyle(color: Colors.white),
        //   ),
        // ),
        backgroundColor: Colors.white,
        body: ListView(
          children: [
            Container(
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage('poto/Cloud.jpg'), fit: BoxFit.cover)),
              height: 900,
              child: Column(
                children: [
                  SizedBox(
                    width: 400,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          alignment: Alignment.centerLeft,
                          margin: EdgeInsets.only(left: 10),
                          child: IconButton(
                            icon: Icon(Icons.arrow_back),
                            onPressed: () {
                              Navigator.push(context,
                                  MaterialPageRoute(builder: (context) {
                                return Second();
                              }));
                            },
                          ),
                        ),
                        Container(
                          alignment: Alignment.topCenter,
                          child: Text('Speed Shop',
                              style: TextStyle(
                                fontFamily: 'san-serif',
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Color.fromARGB(255, 0, 0, 0),
                              )),
                        ),
                        Container(
                          alignment: Alignment.topCenter,
                          margin: EdgeInsets.only(top: 30, bottom: 10),
                          child: Text('Input Profile You',
                              style: TextStyle(
                                fontFamily: 'cursive',
                                fontSize: 60,
                                color: Color.fromARGB(255, 0, 0, 0),
                              )),
                        ),
                        Container(
                          margin: EdgeInsets.only(bottom: 16),
                          child: TextFormField(
                            controller: nama,
                            decoration: InputDecoration(
                              labelText: "Nama",
                              hintText: "Masukkan Nama",
                              prefixIcon: Icon(Icons.person),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(bottom: 16),
                          child: TextFormField(
                            controller: ttl,
                            decoration: InputDecoration(
                              labelText: "Tempat Tanggal Lahir",
                              hintText: "Masukkan Tempat Tanggal Lahir",
                              prefixIcon: Icon(Icons.date_range),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(bottom: 16),
                          child: TextFormField(
                            controller: alamat,
                            decoration: InputDecoration(
                              labelText: "Alamat",
                              hintText: "Masukkan Alamat",
                              prefixIcon: Icon(Icons.nat),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(bottom: 16),
                          child: TextFormField(
                            controller: email,
                            decoration: InputDecoration(
                              labelText: "Email",
                              hintText: "Masukkan Email",
                              prefixIcon: Icon(Icons.email),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(bottom: 0),
                          child: TextFormField(
                            controller: noHp,
                            decoration: InputDecoration(
                              labelText: "No Telepon",
                              hintText: "Masukkan No Telepon Anda",
                              prefixIcon: Icon(Icons.phone),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                            ),
                          ),
                        ),

                        // TextField(
                        //   controller: noHp,
                        //   decoration: InputDecoration(hintText: "Telepon"),
                        //   keyboardType: TextInputType.number,
                        // ),
                      ],
                    ),
                  ),
                  SizedBox(height: 25),
                  ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: Text(
                        'Submit',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      onPressed: () {
                        // ADD DATA HERE
                        users.add({
                          'nama': nama.text,
                          'ttl': ttl.text,
                          'alamat': alamat.text,
                          'email': email.text,
                          'noHp': int.parse(noHp.text)
                        });

                        nama.text = '';
                        ttl.text = '';
                        alamat.text = '';
                        email.text = '';
                        noHp.text = '';
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) {
                          return Read();
                        }));
                      }),
                ],
              ),
            )
          ],
        ));
  }
}

class Read extends StatelessWidget {
  final nama = new TextEditingController();
  final ttl = new TextEditingController();
  final alamat = new TextEditingController();
  final email = new TextEditingController();
  final noHp = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    FirebaseFirestore firestore = FirebaseFirestore.instance;
    CollectionReference users = firestore.collection('posttest7');
    return Scaffold(
        // appBar: AppBar(
        //   title: Text(
        //     'Profile',
        //     style: TextStyle(color: Colors.white),
        //   ),
        //   actions: [
        //     IconButton(
        //       icon: Icon(Icons.arrow_back),
        //       onPressed: () {
        //         Navigator.push(context, MaterialPageRoute(builder: (context) {
        //           return Second();
        //         }));
        //       },
        //     )
        //   ],
        // ),
        // backgroundColor: Colors.white,
        body: Container(
      decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage("poto/Cloud.jpg"),
          fit: BoxFit.cover,
        ),
      ),
      child: Stack(children: [
        ListView(
          children: [
            // VIEW DATA HERE
            StreamBuilder<QuerySnapshot>(
              stream: users.snapshots(),
              builder: (_, snapshot) {
                return (snapshot.hasData)
                    ? Column(
                        children: snapshot.data!.docs
                            .map((e) => ItemCard(
                                  e.get('nama'),
                                  e.get('ttl'),
                                  e.get('alamat'),
                                  e.get('email'),
                                  e.get('noHp'),
                                  //DELETE
                                  onDelete: () {
                                    users.doc(e.id).delete();
                                  },
                                  //UPDATE
                                  onUpdate: () {
                                    showDialog(
                                        context: context,
                                        builder: (context) {
                                          return Container(
                                              child: ListView(children: [
                                            AlertDialog(
                                              title: Text('Update Data'),
                                              content: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  TextField(
                                                    controller: nama,
                                                    decoration: InputDecoration(
                                                        labelText: 'Nama'),
                                                  ),
                                                  TextField(
                                                    controller: ttl,
                                                    decoration: InputDecoration(
                                                        labelText:
                                                            'Tempat Tanggal Lahir'),
                                                  ),
                                                  TextField(
                                                    controller: alamat,
                                                    decoration: InputDecoration(
                                                        labelText: 'Alamat'),
                                                  ),
                                                  TextField(
                                                    controller: email,
                                                    decoration: InputDecoration(
                                                        labelText: 'Email'),
                                                  ),
                                                  TextField(
                                                    controller: noHp,
                                                    decoration: InputDecoration(
                                                        labelText: 'No Hp'),
                                                  ),
                                                ],
                                              ),
                                              actions: [
                                                FlatButton(
                                                  child: Text('Update'),
                                                  onPressed: () {
                                                    users.doc(e.id).update({
                                                      'nama': nama.text,
                                                      'ttl': ttl.text,
                                                      'alamat': alamat.text,
                                                      'email': email.text,
                                                      'noHp':
                                                          int.parse(noHp.text)
                                                    });
                                                    Navigator.push(context,
                                                        MaterialPageRoute(
                                                            builder: (context) {
                                                      return Read();
                                                    }));
                                                  },
                                                )
                                              ],
                                            ),
                                          ]));
                                        });
                                  },
                                ))
                            .toList(),
                      )
                    : Text('Loading...');
              },
            ),
            SizedBox(height: 150),
          ],
        ),
      ]),
    ));
  }
}
// class Edit extends StatefulWidget {
//   final index;
//   final String name;
//   final int age;

//   const Edit({Key? key, required this.name, required this.age, this.index})
//       : super(key: key);

//   @override
//   State<Edit> createState() => _EditState();
// }

// class _EditState extends State<Edit> {
//   final name = new TextEditingController();
//   final age = new TextEditingController();

//   void setdata() {
//     name.text = widget.name;
//     age.text = widget.age.toString();
//     // FirebaseFirestore firestore = FirebaseFirestore.instance;
//     // CollectionReference users = firestore.collection('users');
//     // users
//     //     .doc()
//     //     .update({'nama': name.text, 'age': int.tryParse(age.text) ?? -1});
//   }

//   void initState() {
//     setdata();
//     // updateData();
//     super.initState();
//   }

//   void updateData() {
//     FirebaseFirestore firestore = FirebaseFirestore.instance;
//     CollectionReference users = firestore.collection("anu");
//     users.doc().update({
//       "name": name.text,
//       "age": age.text,
//     });
//     print("update berhasil");
//   }

//   @override
//   Widget build(BuildContext context) {
//     FirebaseFirestore firestore = FirebaseFirestore.instance;
//     CollectionReference users = firestore.collection('anu');
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Update Data'),
//       ),
//       body: Center(
//         child: Column(
//           children: [
//             StreamBuilder<QuerySnapshot>(
//               stream: users.snapshots(),
//               builder: (_, snapshot) {
//                 return (snapshot.hasData)
//                     ? Column(
//                         children: snapshot.data!.docs
//                             .map((e) => ItemCard(
//                                   e.get('name'), e.get('age'),
//                                   //DELETE
//                                   onUpdate: () {
//                                     users.doc(e.id).update({
//                                       'name': name.text,
//                                       'age': int.tryParse(age.text) ?? -1,
//                                     });
//                                   },
//                                 ))
//                             .toList(),
//                       )
//                     : Text('Loading...');
//               },
//             ),
//             SizedBox(height: 150),
//             TextField(
//               controller: name,
//               decoration: InputDecoration(hintText: "Name"),
//             ),
//             TextField(
//               controller: age,
//               decoration: InputDecoration(hintText: "Age"),
//               keyboardType: TextInputType.number,
//             ),
//             OutlinedButton(
//                 child: Text('Update'),
//                 onPressed: () {
//                   users.doc(widget.index).update({
//                     'name': name.text,
//                     'age': age.text,
//                   });
//                   name.text = '';
//                   age.text = '';
//                   print(users.doc(widget.index));
//                 })
//           ],
//         ),
//       ),
//     );
//   }
// }
