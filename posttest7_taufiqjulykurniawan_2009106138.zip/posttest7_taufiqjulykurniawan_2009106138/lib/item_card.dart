import 'package:flutter/material.dart';
import 'package:pertemuan7_crud/halaman4.dart';
import 'package:pertemuan7_crud/main_page.dart';

class ItemCard extends StatelessWidget {
  final String nama;
  final String ttl;
  final String alamat;
  final String email;
  final int noHp;
  //// Pointer to Update Function
  final Function? onUpdate;
  //// Pointer to Delete Function
  final Function? onDelete;

  ItemCard(this.nama, this.email, this.alamat, this.ttl, this.noHp,
      {this.onUpdate, this.onDelete});

  get index => null;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            children: [
              //boxed4(),
              Container(
                alignment: Alignment.centerLeft,
                margin: EdgeInsets.only(left: 10),
                child: IconButton(
                  icon: Icon(Icons.arrow_back),
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) {
                      return Second();
                    }));
                  },
                ),
              ),
              Container(
                alignment: Alignment.topCenter,
                child: Text('Speed Shop',
                    style: TextStyle(
                      fontFamily: 'san-serif',
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color.fromARGB(255, 0, 0, 0),
                    )),
              ),
              Container(
                alignment: Alignment.topCenter,
                margin: EdgeInsets.only(top: 30),
                child: Text('Profile You',
                    style: TextStyle(
                      fontFamily: 'cursive',
                      fontSize: 70,
                      color: Color.fromARGB(255, 0, 0, 0),
                    )),
              ),
              Container(
                margin: EdgeInsets.only(bottom: 10),
                alignment: Alignment.centerLeft,
                height: 60,
                width: 400,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Color(0xfff78000))),
                child: Text(
                  "Nama : $nama",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(bottom: 10),
                alignment: Alignment.centerLeft,
                height: 60,
                width: 400,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Color(0xfff78000))),
                child: Text(
                  "TTL : $ttl",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(bottom: 10),
                alignment: Alignment.centerLeft,
                height: 60,
                width: 400,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Color(0xfff78000))),
                child: Text(
                  "Alamat : $alamat",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(bottom: 10),
                alignment: Alignment.centerLeft,
                height: 60,
                width: 400,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Color(0xfff78000))),
                child: Text(
                  "Email : $email",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
              ),
              Container(
                alignment: Alignment.centerLeft,
                height: 60,
                width: 400,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Color(0xfff78000))),
                child: Text(
                  "No Hp : $noHp",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Container(
                margin: EdgeInsets.only(left: 100, top: 20),
                child: SizedBox(
                  height: 40,
                  width: 60,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: Colors.green[900],
                      ),
                      child: Text("Edit"),
                      onPressed: () {
                        if (onUpdate != null) onUpdate!();
                      }),
                ),
              ),
              Container(
                margin: EdgeInsets.only(right: 100, top: 20, left: 10),
                child: SizedBox(
                  height: 40,
                  width: 80,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: Colors.red[900],
                      ),
                      child: Text("Delete"),
                      onPressed: () {
                        if (onDelete != null) onDelete!();
                      }),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}

Widget boxed4() {
  return Container(
    alignment: Alignment.center,
    child: Container(
      margin: EdgeInsets.only(
        top: 2,
      ),
      width: 400,
      height: 170,
      decoration: BoxDecoration(
        color: Colors.transparent,
      ),
      child: Stack(children: [
        Container(
          alignment: Alignment.topCenter,
          child: Text('Speed Shop',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 0, 0, 0),
              )),
        ),
        Container(
          alignment: Alignment.topCenter,
          margin: EdgeInsets.only(top: 30),
          child: Text('Profile You',
              style: TextStyle(
                fontFamily: 'cursive',
                fontSize: 70,
                color: Color.fromARGB(255, 0, 0, 0),
              )),
        ),
      ]),
    ),
  );
}
