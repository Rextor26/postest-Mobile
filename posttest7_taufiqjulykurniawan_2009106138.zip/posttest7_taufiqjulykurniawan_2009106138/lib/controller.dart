import 'package:get/get.dart';
import 'package:flutter/material.dart';

class TextController extends GetxController {
  var nama = "".obs;
  final namaEditingController = TextEditingController();
}
