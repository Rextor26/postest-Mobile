package com.example.posttest6_taufiqjulykurniawan_2009106138

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
