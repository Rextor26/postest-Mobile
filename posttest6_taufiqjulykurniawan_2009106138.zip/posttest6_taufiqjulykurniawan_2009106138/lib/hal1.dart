import 'package:flutter/material.dart';
import 'package:posttest6_taufiqjulykurniawan_2009106138/chats.dart';
import 'package:posttest6_taufiqjulykurniawan_2009106138/hal3.dart';

class header1 extends StatelessWidget {
  const header1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.only(bottom: 0),
        child: Column(children: [
          Container(
            height: MediaQuery.of(context).size.height / 15,
            child: Stack(
              children: [
                Container(
                  height: MediaQuery.of(context).size.height / 8,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30),
                    ),
                    color: Colors.red,
                  ),
                ),
                katalog(context),
              ],
            ),
          ),
        ]));
  }
}

class header extends StatelessWidget {
  const header({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.only(bottom: 0),
        child: Column(children: [
          Container(
            height: MediaQuery.of(context).size.height / 15,
            child: Stack(
              children: [
                Container(
                  height: MediaQuery.of(context).size.height / 8,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30),
                    ),
                    color: Colors.red,
                  ),
                ),
                katalog(context),
              ],
            ),
          ),
          title(),
          chat(),
        ]));
  }
}

Widget katalog(BuildContext context) {
  return Container(
    child: Row(
      children: [
        Container(
          alignment: Alignment.centerRight,
          margin: EdgeInsets.only(right: 10, left: 20),
          child: ElevatedButton(
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return all();
              }));
            },
            child: Text(
              'All',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 10,
                color: Color.fromARGB(255, 0, 0, 0),
              ),
            ),
          ),
        ),
        Container(
          alignment: Alignment.centerRight,
          margin: EdgeInsets.only(right: 10),
          child: ElevatedButton(
            onPressed: () {},
            child: Text('Recomended',
                style: TextStyle(
                  fontFamily: 'san-serif',
                  fontSize: 12,
                  color: Color.fromARGB(255, 0, 0, 0),
                )),
          ),
        ),
        Container(
          alignment: Alignment.centerRight,
          margin: EdgeInsets.only(right: 10),
          child: ElevatedButton(
            onPressed: () {},
            child: Text('Products',
                style: TextStyle(
                  fontFamily: 'san-serif',
                  fontSize: 12,
                  color: Color.fromARGB(255, 0, 0, 0),
                )),
          ),
        ),
        Container(
          alignment: Alignment.centerLeft,
          margin: EdgeInsets.only(),
          child: ElevatedButton(
            onPressed: () {},
            child: Text('category',
                style: TextStyle(
                  fontFamily: 'san-serif',
                  fontSize: 12,
                  color: Color.fromARGB(255, 0, 0, 0),
                )),
          ),
        ),
      ],
    ),
  );
}
